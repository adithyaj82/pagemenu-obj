//
//  pagetest-Bridging-Header.h
//  pagetest
//
//  Created by adithya on 9/14/18.
//  Copyright © 2018 adithya. All rights reserved.
//

#ifndef pagetest_Bridging_Header_h
#define pagetest_Bridging_Header_h

#import "ViewController.h"
#import "CAPSPageMenu.h"

#import "TestTableViewController.h"
#import "TestCollectionViewController.h"
#import "TestViewController.h"
#endif /* pagetest_Bridging_Header_h */
